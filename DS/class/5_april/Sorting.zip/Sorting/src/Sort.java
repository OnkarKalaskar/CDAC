
public class Sort {

	/*
	 *  n = number of elements in arr.. (input)
	 *  Space = O(1) 
	 *  Time = O( (n) * n ) = O(n*n) = O(n2)
	 * 
	 */
	
	public static void insertionAscending(int []arr)
	{
		for(int j=1; j<arr.length; j++)
		{
			int i=j;
			while(i>0)
			{
				if(arr[i] < arr[i-1])
				{
					int tmp=arr[i];
					arr[i] = arr[i-1];
					arr[i-1]=tmp;
					i--;
				}
				else
					break;
			}
		}
	}
	
	public static void insertionDescending(int []arr)
	{
		for(int j=1; j<arr.length; j++)
		{
			int i=j;
			while(i>0)
			{
				if(arr[i] > arr[i-1])
				{
					int tmp=arr[i];
					arr[i] = arr[i-1];
					arr[i-1]=tmp;
					i--;
				}
				else
					break;
			}
		}
	}
	
	
	/*
	 *  n = number of elements in arr.. (input)
	 *  Space = O(1) 
	 *  Time = O( (n-1) * n) = O(n*n) = O(n2)
	 * 
	 */
	public static void selectionAscending(int []arr)
	{
		int counter=0;
		for(int p=0; p<arr.length-1; p++)   // n-1
		{
			int i=p;
			int x = arr[i];
			
			while(i<arr.length)     //n
			{
				if(arr[i] < x)
				{
					int tmp = arr[i];
					arr[i] = x;
					x = tmp;
				}
				i++;
				counter++;
			}
			arr[p] = x;
		}
		System.out.println(counter);
	}
	
	public static void selectionDescending(int []arr)
	{
		int counter=0;
		for(int p=0; p<arr.length-1; p++)   // n-1
		{
			int i=p;
			int x = arr[i];
			
			while(i<arr.length)     //n
			{
				if(arr[i] > x)
				{
					int tmp = arr[i];
					arr[i] = x;
					x = tmp;
				}
				i++;
				counter++;
			}
			arr[p] = x;
		}
		System.out.println(counter);
	}
	
	/*
	 *  n = number of elements in arr.. (input)
	 *  Space = O(1) 
	 *  Time = O( (n-1) * (n-1) ) = O(n*n) = O(n2)
	 * 
	 */
	public static void bubbleAscending(int []arr)
	{
		for(int j=0; j<arr.length-1; j++)
		{
			for(int i=0; i<arr.length-1; i++)
			{
				if(arr[i+1] < arr[i])
				{
					int tmp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = tmp;
				}
			}
		}
	}
	
	public static void bubbleDescending(int []arr)
	{
		for(int j=0; j<arr.length-1; j++)
		{
			for(int i=0; i<arr.length-1; i++)
			{
				if(arr[i+1] > arr[i])
				{
					int tmp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = tmp;
				}
			}
		}
	}
	
	
	public static void print(int [] arr)
	{
		for (int i = 0; i < arr.length; i++) {  //n
			System.out.print(arr[i] + ", ");
		}
		System.out.println();		
	}
}
