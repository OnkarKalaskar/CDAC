
public class Student {
	
	private String name;
	private int age;
	private char gender;
	private int marks;
	
	Student(String name, int age, char gender, int marks) {
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.marks = marks;
	}

	public String toString() {
		//Shrinivas,34,M
		String str = this.name + ":" + this.age + ":" + this.gender + ":" + this.marks;
		return str;
	}

	/*
	 *  n = number of elements in arr.. (input)
	 *  Space = O(1) 
	 *  Time = O( (n-1) * n) = O(n*n) = O(n2)
	 *  selection sort algo... Ascending
	 */
	public static void sortByAgeAscending(Student []arr)
	{
		for(int p=0; p<arr.length-1; p++)   // n-1
		{
			int i=p;
			Student x = arr[i];
			
			while(i<arr.length)     //n
			{
				//Sort as per age..
				if(arr[i].age < x.age)
				{
					Student tmp = arr[i];
					arr[i] = x;
					x = tmp;
				}
				i++;
			}
			arr[p] = x;
		}
	}
	
	public static void sortByNameAscending(Student []arr)
	{
		for(int p=0; p<arr.length-1; p++)   // n-1
		{
			int i=p;
			Student x = arr[i];
			
			while(i<arr.length)     //n
			{
				//Sort as per age..
				//if(arr[i].age < x.age)
				//https://docs.oracle.com/javase/7/docs/api/java/lang/String.html#compareTo(java.lang.String)
				if(arr[i].name.compareToIgnoreCase(x.name) < 0)
				{
					Student tmp = arr[i];
					arr[i] = x;
					x = tmp;
				}
				i++;
			}
			arr[p] = x;
		}
	}
	
	public static void sortByMarksDescending(Student []arr)
	{
		int counter=0;
		for(int p=0; p<arr.length-1; p++)   // n-1
		{
			int i=p;
			Student x = arr[i];
			
			while(i<arr.length)     //n
			{
				if(arr[i].marks > x.marks)
				{
					Student tmp = arr[i];
					arr[i] = x;
					x = tmp;
				}
				i++;
				counter++;
			}
			arr[p] = x;
		}
		System.out.println(counter);
	}
	
	public static void print(Student [] arr)
	{
		System.out.println("********************************");
		for (int i = 0; i < arr.length; i++) {  //n
			System.out.println(arr[i]);
		}
		System.out.println();		
	}
	
}
