
public class Main {

	public static void main(String[] args) {
		
		Student s1 = new Student("Ram", 22, 'M', 340);
		Student s2 = new Student("prachi", 21, 'M', 400);
		Student s3 = new Student("Pooja", 24, 'F', 30);
		Student s4 = new Student("Prachi", 28, 'F', 40);
		Student s5 = new Student("Dinesh", 12, 'M', 200);
		
		Student [] students = new Student[5];
		students[0] = s1;
		students[1] = s2;
		students[2] = s3;
		students[3] = s4;
		students[4] = s5;
		
		Student.print(students);
		Student.sortByAgeAscending(students);
		Student.print(students);
		Student.sortByMarksDescending(students);
		Student.print(students);
		Student.sortByNameAscending(students);
		Student.print(students);
	
	}
}

